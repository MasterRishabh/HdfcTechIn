package hello.dataExtraction;

//// This sample uses the Apache HTTP client from HTTP Components (http://hc.apache.org/httpcomponents-client-ga/)
import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

@Component
public class AnswerExtractor 
{
 public String extract(String question) 
 {
     HttpClient httpclient = HttpClients.createDefault();
     String answer = "";

     try	
     {
         URIBuilder builder = new URIBuilder("https://westus.api.cognitive.microsoft.com/qnamaker/v2.0/knowledgebases/c21428c0-e45e-4ef5-99b9-d4bb0bf7b037/generateAnswer");


         URI uri = builder.build();
         HttpPost request = new HttpPost(uri);
         request.setHeader("Content-Type", "application/json");
         request.setHeader("Ocp-Apim-Subscription-Key", "395d3ef4c4574b278f39566201371d65");


         // Request body
         StringEntity reqEntity = new StringEntity("{\"question\":\"" + question + "\"}");
         request.setEntity(reqEntity);

         HttpResponse response = httpclient.execute(request);
         HttpEntity entity = response.getEntity();

         if (entity != null) 
         {
        	 answer = EntityUtils.toString(entity);
			 
         }
     }
     catch (Exception e)
     {
         System.out.println(e.getMessage());
     }
     return answer;
 }
}	