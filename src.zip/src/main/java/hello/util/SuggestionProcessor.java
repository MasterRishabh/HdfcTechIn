package hello.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import hello.Application;

public class SuggestionProcessor {

	private static Set<String> insrTypes = new HashSet<>(Arrays.asList("health", "life", "general", "motor", "property"));
	
	public static List<String> fetchSuggestion(String inputQuestion, List<String> keywords) {
		List<String> suggestions = new ArrayList<>();
		 String selectedQuestion1 = "";
		 String selectedQuestion2 = "";
		int high = -1;
		
		if (inputQuestion.startsWith("What is ")) {
			inputQuestion = inputQuestion.substring(8);
		}
		
		if (inputQuestion.endsWith("?")) {
			inputQuestion = inputQuestion.substring(0, inputQuestion.length()-1);
		}
		
		for (String ques : Application.qList) {
			if (!ques.equalsIgnoreCase(inputQuestion)) {
				int count = 0;
				StringTokenizer token = new StringTokenizer(ques, " ");
				while (token.hasMoreTokens()) {
					String word = token.nextToken();
					for (String kword : keywords) {
						if (word.contentEquals(kword)) {
							count++;
						}
					}

				}
				if (count >= high && ques.length() > selectedQuestion2.length()) {
					high = count;
					selectedQuestion2 = selectedQuestion1;
					selectedQuestion1 = ques;
					
				}
			}
            
		}
		suggestions.add("What is " + selectedQuestion1 + "?");
		suggestions.add("What is " + selectedQuestion2 + "?");
		return suggestions;

	}
	
	public static String fetchInsuanceType(String content) {
		StringTokenizer token = new StringTokenizer(content, " ");
		while (token.hasMoreTokens()) {
			String word = token.nextToken();
			if (insrTypes.contains(word.toLowerCase())) {
				return word.toLowerCase(); 
			}
		}
		return "life";
		
	}
}
