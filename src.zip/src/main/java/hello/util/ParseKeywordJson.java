package hello.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import hello.response.KeywordResponse;

public class ParseKeywordJson {
	
	public static KeywordResponse parsonJson(String jsonString) {
		KeywordResponse doc = new KeywordResponse();
		Gson gson=new GsonBuilder().setPrettyPrinting().create();
		doc=gson.fromJson(jsonString,KeywordResponse.class);
		return doc;
	}

}
