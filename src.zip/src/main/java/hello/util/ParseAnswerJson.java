package hello.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import hello.response.Answers;

public class ParseAnswerJson {
	public static Answers parsonJson(String jsonString) {
		Answers answers = new Answers();
		Gson gson=new GsonBuilder().setPrettyPrinting().create();
		answers=gson.fromJson(jsonString,Answers.class);
		return answers;
	}
	
	

}
