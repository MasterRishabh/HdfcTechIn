package hello;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	
	public static List<String> qList;
	static {
		
		Path path = Paths.get("questions.txt");
		try{

		  qList = Files.readAllLines(path);


		  }catch(IOException ex){
		  ex.printStackTrace();//handle exception here
		}
	}

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
