package hello.response;

public class DocumentIn {
    public String id, language, text;

    public DocumentIn(String id, String language, String text){
        this.id = id;
        this.language = language;
        this.text = text;
    }
}
