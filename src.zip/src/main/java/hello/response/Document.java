
package hello.response;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "keyPhrases",
    "id"
})
public class Document {

    @JsonProperty("keyPhrases")
    private List<String> keyPhrases = null;
    @JsonProperty("id")
    private String id;

    @JsonProperty("keyPhrases")
    public List<String> getKeyPhrases() {
        return keyPhrases;
    }

    @JsonProperty("keyPhrases")
    public void setKeyPhrases(List<String> keyPhrases) {
        this.keyPhrases = keyPhrases;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

}
