package hello.response;

import java.util.ArrayList;
import java.util.List;

import hello.response.DocumentIn;

public class DocumentsIn {
    public List<DocumentIn> documents;

    public DocumentsIn() {
        this.documents = new ArrayList<DocumentIn>();
    }
    public void add(String id, String language, String text) {
        this.documents.add (new DocumentIn (id, language, text));
    }
}
