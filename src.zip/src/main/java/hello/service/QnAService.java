package hello.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hello.dataExtraction.AnswerExtractor;
import hello.dataExtraction.GetKeyPhrases;
import hello.response.DocumentsIn;
import hello.response.KeywordResponse;
import hello.response.Answers;
import hello.util.ParseAnswerJson;
import hello.util.ParseKeywordJson;
import hello.util.SuggestionProcessor;


@Service
public class QnAService {
	
	@Autowired
	private AnswerExtractor ansExtract;
	
	public String getResponse(String question) {
		String result = ansExtract.extract(question);
		Answers parsonJson = ParseAnswerJson.parsonJson(result);
		
		String suggestion1 = "";
		String suggestion2 = "";
		List<String> suggestions = null;
		String strs [] = {"Benefits of being an insured", "Advantages/Disadvantages of insurance"};
    	
		

        try {
            DocumentsIn documents = new DocumentsIn ();
            documents.add ("1", "en", question);
            
            String keywordJson = GetKeyPhrases.GetKeyPhrases(documents);
            System.out.println (GetKeyPhrases.prettify (keywordJson));
            KeywordResponse parsedKeyword = ParseKeywordJson.parsonJson(keywordJson);
            
            if (parsedKeyword.getDocuments().get(0).getKeyPhrases().size() == 0) {
            	suggestion1 = strs[0];
                suggestion2 = strs[1];
            }
            
            else if (parsedKeyword.getDocuments().get(0).getKeyPhrases().size() == 1 && parsedKeyword.getDocuments().get(0).getKeyPhrases().get(0).equalsIgnoreCase("insurance")) {
            	suggestion1 += "Types of " + parsedKeyword.getDocuments().get(0).getKeyPhrases().get(0);
            	Random random = new Random();
            	suggestion2 += strs[random.nextInt(strs.length)];
            	
            }
            else {
            	suggestions = SuggestionProcessor.fetchSuggestion(question, parsedKeyword.getDocuments().get(0).getKeyPhrases());
                suggestion1 = suggestions.get(0);
                suggestion2 = suggestions.get(1);
            }
            
            
        }
        catch (Exception e) {
            System.out.println (e);
        }
        
        String insuranceType = SuggestionProcessor.fetchInsuanceType(question + " " + parsonJson.getAnswers().get(0).getAnswer());
    
        String response = "{\"answer\" : \"" + parsonJson.getAnswers().get(0)
        		.getAnswer()+ "\", \"suggestion\": [\""+ suggestion1 +"\", \""+ suggestion2 + "\"], \"insuranceType\":\""+insuranceType+"\"}";
		return response;
	}
	
}
