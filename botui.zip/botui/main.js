var url = 'https://westus.api.cognitive.microsoft.com/qnamaker/v2.0/knowledgebases/c21428c0-e45e-4ef5-99b9-d4bb0bf7b037/generateAnswer';
function fetchResponse(query) {
    var data = {question: query};
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        header:{
            'Ocp-Apim-Subscription-Key' : '395d3ef4c4574b278f39566201371d65'
        },
        success: function(data){
            updateUI(data.Answer)
        },
    });
}