var botui = new BotUI('hello-world');

var baseURL = "http://192.168.20.40:8080/";
var suggestionStore = [];
var convCount = 0;
var correctAnswerCount = 0;
var totalQuestionsAttempted = 0;
var policies = {
    health: [
        {
            name: 'HDFC Life Easy Health Plan',
            img: 'https://brandsite-static.hdfclife.com/media/image/health_plans_WItwe88.png',
            content: 'Health is the most important asset you have. Every aspect of your life is dependent on your good health.'
        },
        {
            name: 'HDFC Life Cancer Care Plan',
            img: 'https://brandsite-static.hdfclife.com/media/image/health-plans.png',
            content: 'HDFC Life Cancer Care offers lump sum benefit on diagnosis of Cancer that helps to protect your income and savings from expenses'
        }
    ],
    life: [
        {
            name: 'HDFC Life Click 2 Retire - ULIP',
            img: 'https://brandsite-static.hdfclife.com/media/image/retirement_plans.png',
            content: 'HDFC Life Click 2 Retire– ULIP is an online Unit Linked Plan that offers you market linked returns, with minimal charges'
        },
        {
            name: 'HDFC Life Click2Invest - ULIP',
            img: 'https://brandsite-static.hdfclife.com/media/image/investment_plans.png',
            content: 'A term plan is what comes handy, if something untoward happens to you. HDFC Life Click 2 Protect 3D Plus helps you customise your term plan along with a choice of 9 plan options'
        }
    ],
    motor: [
        {
            name: 'HDFC Life 2 Wheeler Insurance',
            img: 'https://brandsite-static.hdfclife.com/media/image/protection_plans.png',
            content: 'A term plan is what comes handy, if something untoward happens to you. HDFC Life Click 2 Protect 3D Plus helps you customise your term plan along with a choice of 9 plan options'
        },
        {
            name: 'HDFC Life 4 Wheeler Insurance',
            img: 'https://brandsite-static.hdfclife.com/media/image/retirement_plans.png',
            content: 'A term plan is what comes handy, if something untoward happens to you. HDFC Life Click 2 Protect 3D Plus helps you customise your term plan along with a choice of 9 plan options'
        }
    ],
    property: [
        {
            name: 'HDFC Life Apartment Insurance',
            img: 'https://brandsite-static.hdfclife.com/media/image/protection_plans.png',
            content: 'A term plan is what comes handy, if something untoward happens to you. HDFC Life Click 2 Protect 3D Plus helps you customise your term plan along with a choice of 9 plan options'
        },
        {
            name: 'HDFC Life Home Insurance',
            img: 'https://brandsite-static.hdfclife.com/media/image/retirement_plans.png',
            content: 'A term plan is what comes handy, if something untoward happens to you. HDFC Life Click 2 Protect 3D Plus helps you customise your term plan along with a choice of 9 plan options'
        }
    ]
}

var newsFeeds;
var feedIndex = 0;
var couponFeed;
var couponIndex = 0;
$(document).ready(function () {
    var url = 'http://webhose.io/filterWebContent?token=337a1801-2821-4855-ab1d-5c3acca357a4&format=json&ts=1510257448860&sort=performance_score&q=thread.country%3AIN%20thread.title%3AInsurance';
    var couponURL = 'http://demo.coupomated.com/apiv2/demoBasicFeed.php?key=de70-df65-72b8-d68f&format=json';
    $.ajax({
        type: "GET",
        url: url,
        success: function (data) {
            newsFeeds = data;
            updateFeeds();
        }
    });
    showPolicy("life");
    $("#divEvent").click(function () {
        window.open("https://skillenza.com/challenge/insuretechathon", "_blank");
    });

    $.ajax({
        type: "GET",
        url: couponURL,
        success: function (data) {
            couponFeed = data.DATAFEED.COUPON_ITEM;
        }
    })
});

function updateFeeds() {
    if (feedIndex == newsFeeds.posts.length)
        feedIndex = 0;
    var p1 = newsFeeds.posts[feedIndex].thread;
    feedIndex++;
    if (feedIndex == newsFeeds.posts.length)
        feedIndex = 0;
    var p2 = newsFeeds.posts[feedIndex].thread;
    feedIndex++;

    $('#titleFeed1').html(p1.title.slice(0, 100));
    $('#bodyFeed1').html("<a href='" + p1.url + "'>Visit Page</a>");
    $("#imgFeed1").attr("src", p1.main_image);
    $("#divFeed1").click(genOnClick(p1.url));

    $('#titleFeed2').html(p2.title.slice(0, 100));
    $('#bodyFeed2').html("<a href='" + p2.url + "'>Visit Page</a>");
    $("#imgFeed2").attr("src", p2.main_image);
    $("#divFeed2").click(genOnClick(p2.url));

    setTimeout(function () {
        updateFeeds();
    }, 5000);
}

function genOnClick(u) {
    return function () {
        window.open(u, '_blank');
    }
}
function showPolicy(type) {
    $("#policy1").css("background", "#D2E4F7");
    setTimeout(function () {
        $("#policy1").css("background", "#FFFFFF");
    }, 300);
    $("#policy2").css("background", "#D2E4F7");
    setTimeout(function () {
        $("#policy2").css("background", "#FFFFFF");
    }, 300);
    if (type.localeCompare("life") == 0) {
        $("#titlePolicy1").html(policies.life[0].name);
        $("#imgPolicy1").attr("src", policies.life[0].img);
        $("#contentPolicy1").html(policies.life[0].content);

        $("#titlePolicy2").html(policies.life[1].name);
        $("#imgPolicy2").attr("src", policies.life[1].img);
        $("#contentPolicy2").html(policies.life[1].content);

    }
    if (type.localeCompare("health") == 0) {
        $("#titlePolicy1").html(policies.health[0].name);
        $("#imgPolicy1").attr("src", policies.health[0].img);
        $("#contentPolicy1").html(policies.health[0].content);

        $("#titlePolicy2").html(policies.health[1].name);
        $("#imgPolicy2").attr("src", policies.health[1].img);
        $("#contentPolicy2").html(policies.health[1].content);
    }
    if (type.localeCompare("motor") == 0) {
        $("#titlePolicy1").html(policies.motor[0].name);
        $("#imgPolicy1").attr("src", policies.motor[0].img);
        $("#contentPolicy1").html(policies.motor[0].content);

        $("#titlePolicy2").html(policies.motor[1].name);
        $("#imgPolicy2").attr("src", policies.motor[1].img);
        $("#contentPolicy2").html(policies.motor[1].content);
    }
    if (type.localeCompare("property") == 0) {
        $("#titlePolicy1").html(policies.property[0].name);
        $("#imgPolicy1").attr("src", policies.property[0].img);
        $("#contentPolicy1").html(policies.property[0].content);

        $("#titlePolicy2").html(policies.property[1].name);
        $("#imgPolicy2").attr("src", policies.property[1].img);
        $("#contentPolicy2").html(policies.property[1].content);
    }

}

function callUI(message) {
    var ref = botui.message.add({
        loading: true
    });
    var data = {answer: message, suggestion: []};
    updateUI(data, ref);
}
callUI("Hello");
var url = baseURL;
//var url = 'https://694c2128.ngrok.io';
//            var url = 'https://westus.api.cognitive.microsoft.com/qnamaker/v2.0/knowledgebases/c21428c0-e45e-4ef5-99b9-d4bb0bf7b037/generateAnswer';
//            var url = 'https://westus.api.cognitive.microsoft.com/qnamaker/v2.0/knowledgebases/c21428c0-e45e-4ef5-99b9-d4bb0bf7b037/generateAnswer';
function fetchResponse(query) {
    var ref = botui.message.add({
        loading: true
    });
    var data = {question: query};
    $.ajax({
        type: "GET",
        url: url,
        data: data,
        success: function (data) {

            console.log("Success: " + data);
            data.replace(/(?:\r\n|\r|\n)/g, ' ');
            var obj = JSON.parse(data);
//            console.log("----" + obj.answer);
//                        console.log("Success: " + JSON.stringify(data) + data.answers[0].answer);
            console.log("Type:  " + obj.insuranceType);
            showPolicy(obj.insuranceType);
            updateUI(obj, ref)
        },
        failure: function (data) {
            console.log("Error: " + data);
            //                      updateUI("Error...")
        }
    });
}


function updateUI(response, ref) {
    convCount++;
    ref.then(function (index) {
        botui.message.update(index, {
            content: response.answer,
            loading: false
        }).then(function () {

            if (response.suggestion.length == 0) {
                botui.action.text({
                    action: {}
                }).then(function (data) {
                    console.log("Query: " + data.value);
                    fetchResponse(data.value);
                });
            } else {
                var buttons = [];
                if (suggestionStore.length > 0 && suggestionStore.length % 3 == 0) {
                    response.suggestion[response.suggestion.length] = "Take a Quiz";
                }
                response.suggestion[response.suggestion.length] = "Skip";
                for (i = 0; i < response.suggestion.length; i++) {
                    buttons.push({
                        text: response.suggestion[i],
                        value: response.suggestion[i]
                    });
                }
                botui.action.button({
                    delay: 1000,
                    addMessage: true, // so we could the address in message instead if 'Existing Address'
                    action: buttons
                }).then(function (data) {
                    if (data.value.toString().localeCompare("Skip") == 0) {
                        callUI("Enter Your Query");
                        return;
                    }
                    if (data.value.toString().localeCompare("Take a Quiz") == 0) {
                        askQuiz();
                        return
                    }
                    console.log("Query: " + data.value);
                    suggestionStore.push(data.value);
                    console.log("suggestionStore: " + suggestionStore);
                    fetchResponse(data.value);
                });
            }

        });
    });
}
function askQuiz() {
    var ref = botui.message.add({
        loading: true
    });
    var rand1 = Math.floor(Math.random() * (suggestionStore.length - 1 + 1));
    var rand2 = Math.floor(Math.random() * (suggestionStore.length - 1 + 1));
    if (rand1 == rand2) {
        if (rand2 > 0)
            rand2--;
        else
            rand2++;
    }
    console.log("r1: " + rand1 + "   r2: " + rand2);
    var option1 = getResponse(suggestionStore[rand1]).answer;
    var obj2 = getResponse(suggestionStore[rand2]);
    var option2 = obj2.answer;
    console.log("option1: " + option1);
    console.log("option2: " + option2);

    ref.then(function (index) {
        botui.message.update(index, {
            content: suggestionStore[rand1] + " - Choose the right Option",
            loading: false
        }).then(function () {
            var buttons = [];
            buttons.push({
                text: option1,
                value: option1
            });
            buttons.push({
                text: option2,
                value: option2
            });
            buttons.push({
                text: 'Skip',
                value: 'Skip'
            });
            botui.action.button({
                delay: 1000,
                addMessage: true, // so we could the address in message instead if 'Existing Address'
                action: buttons
            }).then(function (data) {
                totalQuestionsAttempted++;
                if (data.value.toString().localeCompare("Skip") == 0) {
                    callUI("Better Luck Next time Score: " + correctAnswerCount + "/" + totalQuestionsAttempted);
                    return;
                }
                if (data.value.toString().localeCompare(option1) == 0) {
                    correctAnswerCount++;
                    var coupon = "<br/><img src = 'assets/coupon.png' width='120' height=70>";
                    callUI("Correst Answer. Score: " + correctAnswerCount + "/" + totalQuestionsAttempted +coupon+ getCouponData());
                    return;
                } else {
                    callUI("Better Luck Next time Score: " + correctAnswerCount + "/" + totalQuestionsAttempted);
                    return;
                }
            });
        });
    });
}

function getCouponData() {
    var coupon = couponFeed[couponIndex];
    couponIndex++;

    var data = "<br/><b>congratulations!</b><br/> You have won a <b>COUPON!!!</b>"
            + "<br/><b>" + coupon.TITLE + "</b>"
            + "<br/>Store: <b>" + coupon.STORE_NAME + "</b>"
            + "<br/><a href='"+coupon.LINK+"'>Visit</a>";
    return data;
}

function imageSearch(q){
    var gettyURL = 'https://api.gettyimages.com/v3/search/images';
    $.ajax({
        type: "GET",
        url: gettyURL,
        data: {
            phrase: q
        },
        headers:{
            'Api-Key':'csk5ddxw8jugq4atdea5u2ca' 
        },
        async: false,
        success: function(data){
            
        }
    })

}

function getResponse(query) {
    var data = {question: query};
    var response;
    $.ajax({
        type: "GET",
        url: url,
        data: data,
        async: false,
        success: function (data) {
            response = data;
        }
    });
    return JSON.parse(response);
}
/*
 botui.message.add({
 loading: true
 }).then(function (index) {
 setTimeout(function () {
 botui.message.update(index, {
 content: 'Hello World from bot!',
 loading: false
 }).then(function () {
 botui.message.add({
 delay: 2000,
 loading: true,
 content: 'Delayed Hello World'
 });
 });
 }, 5000);
 });
 
 botui.message.add({
 human: true,
 content: 'Hello World from human!'
 }).then(function () {
 botui.action.text({
 action: {
 button: {
 icon: 'check',
 label: 'Submit'
 }
 }
 });
 });
 */
